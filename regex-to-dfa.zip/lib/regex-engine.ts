// Types
type RegexNode = {
  type: string
  value?: string
  left?: RegexNode
  right?: RegexNode
}

type NFA = {
  states: Record<string, boolean>
  alphabet: string[]
  transitions: Record<string, Record<string, string[]>>
  startState: string
  acceptStates: string[]
}

type DFA = {
  states: Record<string, boolean>
  alphabet: string[]
  transitions: Record<string, Record<string, string>>
  startState: string
  acceptStates: string[]
}

// 1. Regex Parser
export function parseRegex(regex: string): RegexNode {
  let pos = 0

  function parseAtom(): RegexNode {
    if (pos >= regex.length) {
      throw new Error("Unexpected end of regex")
    }

    const char = regex[pos]

    if (char === "(") {
      pos++ // Skip '('
      const node = parseAlternation()

      if (pos >= regex.length || regex[pos] !== ")") {
        throw new Error("Missing closing parenthesis")
      }

      pos++ // Skip ')'
      return node
    } else if (char === "|" || char === ")" || char === "*" || char === "+" || char === "?") {
      throw new Error(`Unexpected character: ${char}`)
    } else {
      pos++ // Consume character
      return { type: "CHAR", value: char }
    }
  }

  function parseRepetition(): RegexNode {
    const node = parseAtom()

    if (pos < regex.length) {
      if (regex[pos] === "*") {
        pos++ // Skip '*'
        return { type: "STAR", left: node }
      } else if (regex[pos] === "+") {
        pos++ // Skip '+'
        return {
          type: "CONCAT",
          left: node,
          right: { type: "STAR", left: node },
        }
      } else if (regex[pos] === "?") {
        pos++ // Skip '?'
        return {
          type: "UNION",
          left: node,
          right: { type: "CHAR", value: "ε" },
        }
      }
    }

    return node
  }

  function parseConcat(): RegexNode {
    let node = parseRepetition()

    while (pos < regex.length && regex[pos] !== "|" && regex[pos] !== ")") {
      const right = parseRepetition()
      node = { type: "CONCAT", left: node, right }
    }

    return node
  }

  function parseAlternation(): RegexNode {
    let node = parseConcat()

    while (pos < regex.length && regex[pos] === "|") {
      pos++ // Skip '|'
      const right = parseConcat()
      node = { type: "UNION", left: node, right }
    }

    return node
  }

  const ast = parseAlternation()

  if (pos < regex.length) {
    throw new Error(`Unexpected character at position ${pos}: ${regex[pos]}`)
  }

  return ast
}

// 2. Convert Regex AST to NFA
export function regexToNFA(ast: RegexNode): NFA {
  let stateCounter = 0

  function createState(): string {
    return (stateCounter++).toString()
  }

  function buildNFA(node: RegexNode): NFA {
    if (node.type === "CHAR") {
      const startState = createState()
      const acceptState = createState()

      const nfa: NFA = {
        states: { [startState]: true, [acceptState]: true },
        alphabet: node.value !== "ε" ? [node.value!] : [],
        transitions: {
          [startState]: {},
        },
        startState,
        acceptStates: [acceptState],
      }

      if (node.value === "ε") {
        nfa.transitions[startState]["ε"] = [acceptState]
      } else {
        nfa.transitions[startState][node.value!] = [acceptState]
      }

      return nfa
    } else if (node.type === "CONCAT") {
      const nfa1 = buildNFA(node.left!)
      const nfa2 = buildNFA(node.right!)

      // Connect nfa1's accept states to nfa2's start state with ε-transitions
      for (const acceptState of nfa1.acceptStates) {
        if (!nfa1.transitions[acceptState]) {
          nfa1.transitions[acceptState] = {}
        }

        if (!nfa1.transitions[acceptState]["ε"]) {
          nfa1.transitions[acceptState]["ε"] = []
        }

        nfa1.transitions[acceptState]["ε"].push(nfa2.startState)
      }

      // Merge the two NFAs
      const mergedNFA: NFA = {
        states: { ...nfa1.states, ...nfa2.states },
        alphabet: [...new Set([...nfa1.alphabet, ...nfa2.alphabet])],
        transitions: { ...nfa1.transitions, ...nfa2.transitions },
        startState: nfa1.startState,
        acceptStates: nfa2.acceptStates,
      }

      return mergedNFA
    } else if (node.type === "UNION") {
      const nfa1 = buildNFA(node.left!)
      const nfa2 = buildNFA(node.right!)

      // Create a new start state
      const newStartState = createState()

      // Create ε-transitions from new start state to the start states of nfa1 and nfa2
      const mergedNFA: NFA = {
        states: {
          [newStartState]: true,
          ...nfa1.states,
          ...nfa2.states,
        },
        alphabet: [...new Set([...nfa1.alphabet, ...nfa2.alphabet])],
        transitions: {
          [newStartState]: {
            ε: [nfa1.startState, nfa2.startState],
          },
          ...nfa1.transitions,
          ...nfa2.transitions,
        },
        startState: newStartState,
        acceptStates: [...nfa1.acceptStates, ...nfa2.acceptStates],
      }

      return mergedNFA
    } else if (node.type === "STAR") {
      const nfa = buildNFA(node.left!)

      // Create a new start state
      const newStartState = createState()

      // Create ε-transition from new start state to nfa's start state
      const starNFA: NFA = {
        states: {
          [newStartState]: true,
          ...nfa.states,
        },
        alphabet: [...nfa.alphabet],
        transitions: {
          [newStartState]: {
            ε: [nfa.startState],
          },
          ...nfa.transitions,
        },
        startState: newStartState,
        acceptStates: [newStartState, ...nfa.acceptStates],
      }

      // Add ε-transitions from nfa's accept states to nfa's start state
      for (const acceptState of nfa.acceptStates) {
        if (!starNFA.transitions[acceptState]) {
          starNFA.transitions[acceptState] = {}
        }

        if (!starNFA.transitions[acceptState]["ε"]) {
          starNFA.transitions[acceptState]["ε"] = []
        }

        starNFA.transitions[acceptState]["ε"].push(nfa.startState)
      }

      return starNFA
    }

    throw new Error(`Unknown node type: ${node.type}`)
  }

  return buildNFA(ast)
}

// 3. Convert NFA to DFA using subset construction
export function nfaToDFA(nfa: NFA): DFA {
  // Helper function to compute epsilon closure
  function epsilonClosure(states: string[]): string[] {
    const visited = new Set<string>(states)
    const stack = [...states]

    while (stack.length > 0) {
      const state = stack.pop()!

      const epsilonTransitions = nfa.transitions[state]?.["ε"] || []

      for (const nextState of epsilonTransitions) {
        if (!visited.has(nextState)) {
          visited.add(nextState)
          stack.push(nextState)
        }
      }
    }

    return Array.from(visited).sort()
  }

  // Helper function to compute the next state set
  function move(states: string[], symbol: string): string[] {
    const nextStates = new Set<string>()

    for (const state of states) {
      const transitions = nfa.transitions[state]?.[symbol] || []

      for (const nextState of transitions) {
        nextStates.add(nextState)
      }
    }

    return Array.from(nextStates)
  }

  // Start with the epsilon closure of the NFA's start state
  const initialDFAState = epsilonClosure([nfa.startState])
  const initialDFAStateName = initialDFAState.join(",")

  const dfa: DFA = {
    states: { [initialDFAStateName]: true },
    alphabet: [...nfa.alphabet],
    transitions: {},
    startState: initialDFAStateName,
    acceptStates: [],
  }

  // Check if the initial state is an accept state
  if (initialDFAState.some((state) => nfa.acceptStates.includes(state))) {
    dfa.acceptStates.push(initialDFAStateName)
  }

  // Queue of DFA states to process
  const queue = [initialDFAState]
  const processedStates = new Set<string>([initialDFAStateName])

  while (queue.length > 0) {
    const currentDFAState = queue.shift()!
    const currentDFAStateName = currentDFAState.join(",")

    // Initialize transitions for this state
    dfa.transitions[currentDFAStateName] = {}

    // For each symbol in the alphabet
    for (const symbol of dfa.alphabet) {
      // Compute the next state set
      const nextNFAStates = epsilonClosure(move(currentDFAState, symbol))

      if (nextNFAStates.length === 0) {
        continue // No transition for this symbol
      }

      const nextDFAStateName = nextNFAStates.join(",")

      // Add the transition
      dfa.transitions[currentDFAStateName][symbol] = nextDFAStateName

      // If this is a new state, add it to the queue
      if (!processedStates.has(nextDFAStateName)) {
        dfa.states[nextDFAStateName] = true
        processedStates.add(nextDFAStateName)
        queue.push(nextNFAStates)

        // Check if it's an accept state
        if (nextNFAStates.some((state) => nfa.acceptStates.includes(state))) {
          dfa.acceptStates.push(nextDFAStateName)
        }
      }
    }
  }

  // Convert DFA state names to simple letters (A, B, C, ...)
  const stateMapping: Record<string, string> = {}
  const stateNames = Object.keys(dfa.states)

  stateNames.forEach((stateName, index) => {
    stateMapping[stateName] = String.fromCharCode(65 + index) // A, B, C, ...
  })

  // Create the renamed DFA
  const renamedDFA: DFA = {
    states: {},
    alphabet: [...dfa.alphabet],
    transitions: {},
    startState: stateMapping[dfa.startState],
    acceptStates: dfa.acceptStates.map((state) => stateMapping[state]),
  }

  // Rename states
  for (const stateName of stateNames) {
    const newName = stateMapping[stateName]
    renamedDFA.states[newName] = true

    // Rename transitions
    renamedDFA.transitions[newName] = {}

    for (const symbol in dfa.transitions[stateName]) {
      const targetState = dfa.transitions[stateName][symbol]
      renamedDFA.transitions[newName][symbol] = stateMapping[targetState]
    }
  }

  return renamedDFA
}
