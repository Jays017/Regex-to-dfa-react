"use client"

import { useState } from "react"
import DFAVisualizer from "@/components/dfa-visualizer"
import TransitionTable from "@/components/transition-table"
import { parseRegex, regexToNFA, nfaToDFA } from "@/lib/regex-engine"

export default function Home() {
  const [regex, setRegex] = useState("(a|b)*c")
  const [nfa, setNfa] = useState(null)
  const [dfa, setDfa] = useState(null)
  const [error, setError] = useState("")

  const handleConvert = () => {
    try {
      setError("")
      // Parse regex to syntax tree
      const ast = parseRegex(regex)
      // Convert syntax tree to NFA
      const newNfa = regexToNFA(ast)
      setNfa(newNfa)
      // Convert NFA to DFA using subset construction
      const newDfa = nfaToDFA(newNfa)
      setDfa(newDfa)
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <main className="min-h-screen p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Regular Expression to DFA Converter</h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Introduction</h2>
            <p className="text-gray-700">
              Convert simple regular expressions to deterministic finite automaton.
              <br />
              Regex → NFA → DFA
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Supported grammars</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>r = (s)</li>
              <li>r = st</li>
              <li>r = s|t</li>
              <li>r = s*</li>
              <li>r = s+</li>
              <li>r = s?</li>
              <li>
                r = ε<br />
                (Copy this character to input if needed)
              </li>
            </ul>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Examples</h2>
            <ul className="list-disc pl-5 space-y-1">
              <li>(a|b)*</li>
              <li>(a*|b*)*</li>
              <li>((c|a)b*)*</li>
              <li>(a|b)*abb(a|b)*</li>
            </ul>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-grow">
              <label htmlFor="regex-input" className="block text-sm font-medium text-gray-700 mb-1">
                Input:
              </label>
              <input
                id="regex-input"
                type="text"
                value={regex}
                onChange={(e) => setRegex(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-md"
              />
            </div>
            <button
              onClick={handleConvert}
              className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-6 rounded"
            >
              CONVERT
            </button>
          </div>

          {error && <div className="mt-4 p-3 bg-red-100 text-red-700 rounded-md">{error}</div>}
        </div>

        {nfa && dfa && (
          <>
            <div className="bg-white p-6 rounded-lg shadow mb-8">
              <div className="flex flex-col md:flex-row justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Transition Tables</h2>
                <div className="text-sm">
                  <a href="#" className="text-blue-600 hover:underline mr-4">
                    NFA: View detailed
                  </a>
                  <a href="#" className="text-blue-600 hover:underline">
                    Min-DFA: View detailed
                  </a>
                </div>
              </div>
              <TransitionTable nfa={nfa} dfa={dfa} />
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">DFA Visualization</h2>
              <DFAVisualizer dfa={dfa} />
            </div>
          </>
        )}
      </div>
    </main>
  )
}
