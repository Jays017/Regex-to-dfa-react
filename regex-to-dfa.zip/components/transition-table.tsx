"use client"

import { useState } from "react"

export default function TransitionTable({ nfa, dfa }) {
  const [activeTab, setActiveTab] = useState("dfa")

  // Get unique alphabet symbols from DFA
  const alphabet = Array.from(new Set(Object.values(dfa.transitions).flatMap(Object.keys))).sort()

  return (
    <div>
      <div className="flex border-b mb-4">
        <button
          className={`px-4 py-2 ${activeTab === "nfa" ? "border-b-2 border-teal-500 font-medium" : "text-gray-500"}`}
          onClick={() => setActiveTab("nfa")}
        >
          NFA
        </button>
        <button
          className={`px-4 py-2 ${activeTab === "dfa" ? "border-b-2 border-teal-500 font-medium" : "text-gray-500"}`}
          onClick={() => setActiveTab("dfa")}
        >
          DFA
        </button>
      </div>

      {activeTab === "nfa" && (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  NFA STATE
                </th>
                {alphabet.map((symbol) => (
                  <th
                    key={symbol}
                    className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {symbol}
                  </th>
                ))}
                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  ε
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {Object.keys(nfa.states).map((state) => (
                <tr key={state}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {state}
                    {nfa.acceptStates.includes(state) ? " (accept)" : ""}
                  </td>
                  {alphabet.map((symbol) => (
                    <td key={symbol} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {nfa.transitions[state]?.[symbol]?.join(", ") || "-"}
                    </td>
                  ))}
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {nfa.transitions[state]?.["ε"]?.join(", ") || "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "dfa" && (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  DFA STATE
                </th>
                <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  TYPE
                </th>
                {alphabet.map((symbol) => (
                  <th
                    key={symbol}
                    className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    {symbol}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {Object.keys(dfa.states).map((state) => (
                <tr key={state}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{state}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {dfa.acceptStates.includes(state) ? "accept" : ""}
                  </td>
                  {alphabet.map((symbol) => (
                    <td key={symbol} className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {dfa.transitions[state]?.[symbol] || "-"}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
