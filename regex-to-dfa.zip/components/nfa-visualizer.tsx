"use client"

import { useEffect, useRef } from "react"

export default function NFAVisualizer({ nfa }) {
  const canvasRef = useRef(null)

  useEffect(() => {
    if (!canvasRef.current || !nfa) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set up the visualization
    const states = Object.keys(nfa.states)
    const stateRadius = 25
    const width = canvas.width
    const height = canvas.height

    // Calculate positions for states
    const positions = {}
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 3

    states.forEach((state, i) => {
      const angle = (i / states.length) * 2 * Math.PI
      positions[state] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      }
    })

    // Draw transitions
    Object.entries(nfa.transitions).forEach(([fromState, transitions]) => {
      Object.entries(transitions).forEach(([symbol, toStates]) => {
        const fromPos = positions[fromState]

        toStates.forEach((toState) => {
          const toPos = positions[toState]

          // Calculate control point for curved lines
          const midX = (fromPos.x + toPos.x) / 2
          const midY = (fromPos.y + toPos.y) / 2
          const dx = toPos.x - fromPos.x
          const dy = toPos.y - fromPos.y
          const normalX = -dy
          const normalY = dx
          const length = Math.sqrt(normalX * normalX + normalY * normalY)
          const controlX = midX + (normalX / length) * 40
          const controlY = midY + (normalY / length) * 40

          // Draw the curved line
          ctx.beginPath()
          ctx.moveTo(fromPos.x, fromPos.y)
          ctx.quadraticCurveTo(controlX, controlY, toPos.x, toPos.y)
          ctx.strokeStyle = "#666"
          ctx.lineWidth = 1.5
          ctx.stroke()

          // Draw arrowhead
          const angle = Math.atan2(toPos.y - controlY, toPos.x - controlX)
          const arrowSize = 8
          ctx.beginPath()
          ctx.moveTo(toPos.x, toPos.y)
          ctx.lineTo(
            toPos.x - arrowSize * Math.cos(angle - Math.PI / 6),
            toPos.y - arrowSize * Math.sin(angle - Math.PI / 6),
          )
          ctx.lineTo(
            toPos.x - arrowSize * Math.cos(angle + Math.PI / 6),
            toPos.y - arrowSize * Math.sin(angle + Math.PI / 6),
          )
          ctx.fillStyle = "#666"
          ctx.fill()

          // Draw the symbol
          ctx.fillStyle = "#000"
          ctx.font = "12px Arial"
          ctx.fillText(symbol, controlX, controlY)
        })
      })
    })

    // Draw states
    states.forEach((state) => {
      const pos = positions[state]

      // Draw circle
      ctx.beginPath()
      ctx.arc(pos.x, pos.y, stateRadius, 0, 2 * Math.PI)
      ctx.fillStyle = "#fff"
      ctx.fill()
      ctx.strokeStyle = nfa.acceptStates.includes(state) ? "#d00" : "#000"
      ctx.lineWidth = nfa.acceptStates.includes(state) ? 2 : 1
      ctx.stroke()

      // Draw double circle for accept states
      if (nfa.acceptStates.includes(state)) {
        ctx.beginPath()
        ctx.arc(pos.x, pos.y, stateRadius - 4, 0, 2 * Math.PI)
        ctx.strokeStyle = "#d00"
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Draw state label
      ctx.fillStyle = "#000"
      ctx.font = "bold 14px Arial"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(state, pos.x, pos.y)
    })

    // Draw start arrow
    const startState = nfa.startState
    const startPos = positions[startState]
    if (startPos) {
      ctx.beginPath()
      ctx.moveTo(startPos.x - stateRadius - 30, startPos.y)
      ctx.lineTo(startPos.x - stateRadius, startPos.y)
      ctx.strokeStyle = "#000"
      ctx.lineWidth = 1.5
      ctx.stroke()

      // Draw arrowhead
      const arrowSize = 8
      ctx.beginPath()
      ctx.moveTo(startPos.x - stateRadius, startPos.y)
      ctx.lineTo(startPos.x - stateRadius - arrowSize, startPos.y - arrowSize)
      ctx.lineTo(startPos.x - stateRadius - arrowSize, startPos.y + arrowSize)
      ctx.fillStyle = "#000"
      ctx.fill()
    }
  }, [nfa])

  return <canvas ref={canvasRef} width={700} height={400} className="w-full h-auto border border-gray-200 rounded-md" />
}
