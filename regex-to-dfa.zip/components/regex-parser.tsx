"use client"

import { useState } from "react"
import { parseRegex } from "@/lib/regex-engine"

export default function RegexParser({ onParse }) {
  const [regex, setRegex] = useState("(a|b)*c")
  const [error, setError] = useState("")

  const handleParse = () => {
    try {
      setError("")
      const ast = parseRegex(regex)
      onParse(ast)
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-grow">
          <label htmlFor="regex-input" className="block text-sm font-medium text-gray-700 mb-1">
            Regular Expression:
          </label>
          <input
            id="regex-input"
            type="text"
            value={regex}
            onChange={(e) => setRegex(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
          />
        </div>
        <button onClick={handleParse} className="bg-teal-600 hover:bg-teal-700 text-white font-bold py-2 px-6 rounded">
          Parse
        </button>
      </div>

      {error && <div className="p-3 bg-red-100 text-red-700 rounded-md">{error}</div>}
    </div>
  )
}
